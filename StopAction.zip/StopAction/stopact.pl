#!C:/Perl/bin/perl.exe -w
$|++;

use strict;
use Carp;
use Tk;               # GUI
use Tk::JPEG;         # GUI
use Tk::Balloon;      # GUI
use Win32;
use Win32::MIDI;
use Win32::API;
use File::Spec;
my $gLocation = '+10+0';
my $i = 0;
my $reps = 3;

my ($main, $menubar, $status, $balloon, $label);
my $autoflag = 0;


sub autooff
{
    $autoflag = 0;
    say("Auto mode is off");
}

sub auto
{
    $autoflag = 1;
    while($autoflag)
    {
	print chr(7);
	select(undef, undef, undef, 0.5);
	print chr(7);
	snap();
        $label->update();
        Tk::DoOneEvent();
	select(undef, undef, undef, 1.0);
    }
}

sub snap
{
  if (!$i)
  {
       $label->delete('0.0','end');
       `rm -rf img*.jpg`;
  }
  `rm -rf image.jpg`;
   my $w = `wget -q http://10.0.0.200/jpg/image.jpg`;

#   `wget http://192.169.0.201/jpg/image.jpg`;
#  my $w = `wget http://info/Museum/images/Butterflies/inside.jpg`;

   for my $j (1..$reps)
   {
       $i++;
       add("Take one Frame[$w]...$i");
      `cp image.jpg img$i.jpg`;
#      `cp inside.jpg img$i.jpg`;
   }
   $label->see('end');
}

# May (or may not) need to escape the asterisk

sub movie
{
    say("Making the Movie...($i Frames)");

    print "CALLING: ffmpeg -f image2 -i img%d.jpg movie.mpg\n";
#    my $rr = `/bin/rm -rf movie.avi`;
#    print "REMOVE(movie.avi): [$rr]\n";

    my $ff = `ffmpeg -v -10 -y -r 10 -b 1800 -i img%d.jpg movie.avi`;

    say("Done making the Movie.");
    $i = 0;
    show();
}

sub show
{
  say("Showing the Movie...");
  $i = 0;
  `C:/cygwin/VLC/vlc.exe movie.avi`;
  say("Ready to start a new Movie.");
}

sub say
{
  $label->delete('0.0','end');
  $label->insert('end', "\n\n ".(shift)."\n", 'normal
}');
  $label->see('end');
}

sub add
{
 $label->insert('end', (shift)."\n", 'normal');
}

BEGIN {
}

   initGUI();
   $main->bind("<KeyPress-t>", \&snap );
   $main->bind("<KeyPress-a>", \&auto );
   $main->bind("<KeyPress-o>", \&autooff );
   $main->bind("<KeyPress-m>", \&movie );
   $main->bind("<KeyPress-s>",  \&show );
   $main->bind("<KeyPress-t>", \&snap );
   $main->bind("<KeyPress-m>", \&movie );
   $main->bind("<Escape>",  sub { Tk::exit(0); } );
   textArea();

   say("Ready to start a new Movie.");
   MainLoop;

sub initGUI {
   $main = new MainWindow;
   $main->withdraw();
   $main->title("Stop Action Studio 1.0");
   $main->geometry($gLocation);
   $status = $main->Label( -relief=>"sunken", -borderwidth=>2, -anchor=>"w" );
   $menubar = $main->Frame(-relief=>"raised",  -borderwidth=>2);
   $balloon = $main->Balloon(-background => 'white', -foreground => 'black' );
   $balloon->attach($status, -msg => "Messages Appear Here");
}

sub newIcon {
    my ($icon) = @_;
   $main->Icon(-image => $main->Photo(-file => $icon));
}

sub textArea {
    my $new = (!defined($label) || ($label->class() ne 'Text'));

    if ($new) {
    	    unPack();
	    $label = $main->Scrolled('Text', -font => 'courier 14 bold'); # , -justify => 'left' );
	    $label->Scrollbar(-orient => 'vertical');
	    $balloon->attach($label, -balloonposition => 'mouse',
	       -msg => "You can change to a picture if you like");
    }
    $label->insert('0.0', $_[0], 'normal');

 my $nlines = $label->index('end');  # returns Lines.Chars
    $nlines =~ s/\.[0-9]+//;         # remove .Chars part
    $label->configure(-height => 10, -width => 30
);
    if ($new) { packAll(); }
}

sub pictureArea {
    my $filename = shift;
    return unless -e $filename;
    my $class = $label->class();

    if ($class ne "Label") {
	unPack();
	$label = $main->Scrolled('Label');
	$balloon->attach($label, -balloonposition => 'mouse',
	       -msg => "You can change this picture if you like");
    }

    $label->configure(-image => $label->Photo(-file => $filename));
    if ($class ne "Label") { packAll(); }
}

# Now pack it: Menu on top, Image Area in the middle , Status at bottom
sub packAll {
    $menubar->pack(-side=>"top", -fill=>"x");
    $label->pack(-side=>"top", -expand=>1, -padx=>10, -pady=>10);
    $status->pack(-side=>"top", -fill=>"x");
    $main->raise();
    $main->deiconify();
}

sub unPack {
    if (defined($label)) {
	$menubar->packForget();
	$label->packForget();
	$status->packForget();
    }
}

# Set status area text string
sub stext { $status->configure(-text=> (shift)); }

